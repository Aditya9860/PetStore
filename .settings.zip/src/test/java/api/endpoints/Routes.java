package api.endpoints;

public class Routes {
  public static String base_URl = "https://petstore.swagger.io/v2";
  public static String post_URL= base_URl+"/user";
  public static String get_URL = base_URl + "/user/{username}"; 
  public static String update_URL = base_URl + "/user/{username}";
  public static String delete_URL = base_URl +"/user/{username}";
}
